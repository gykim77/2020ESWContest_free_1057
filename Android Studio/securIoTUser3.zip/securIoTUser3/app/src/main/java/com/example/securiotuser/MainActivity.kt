package com.example.securiotuser

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap


class MainActivity : AppCompatActivity() {
    private val tag = "MainActivity"

    private lateinit var result1: ArrayList<String>
    private lateinit var adapter1: ArrayAdapter<String>
    private lateinit var result2: ArrayList<String>
    private lateinit var adapter2: ArrayAdapter<String>
    lateinit var listView : ListView
    lateinit var bitmap: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //이전 인텐트에서 값 받아오기
        val ran = IntRange(0,6)
        val name = intent.getStringExtra("ID").toString()
        if (name.count() >= 6){
            hell_text.text = "안녕하세요! ${name.slice(ran)}님 :)"
        }else{
            hell_text.text = "안녕하세요! ${name}님 :)"
        }

        //뒤로가기
        back_button_1.setOnClickListener{
            finish()
        }

        //최근 냉장고 사용 시각
        val restTask2 = RestTask2(name)
        val getResult1: String = restTask2.execute().get()
        lastOpen.text = getResult1

        //음식 목록
        result1 = arrayListOf()
        adapter1 = ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, result1)
        foodList.adapter = adapter1
        result1.clear()

//        val restTask3 = RestTask3(name)
//        val getResult2 = restTask3.execute().get()
//
//        val resultSplit = getResult2.split(' ')
//        for(i in 0 until resultSplit.count()-1){
//            val resultSplit2 = resultSplit[i].split('_')
//            Log.e(tag, "RFID: ${resultSplit2[2]} 무게: ${resultSplit2[0]} 보관일자: ${resultSplit2[1]}")
//            result1.add("RFID: ${resultSplit2[2]} 무게: ${resultSplit2[0]} 보관일자: ${resultSplit2[1]}")
//        }
//        adapter1.notifyDataSetChanged()

        //도난 상황 목록
//        result2 = arrayListOf()
//        adapter2= ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, result2)
//        camList.adapter = adapter2
//        result1.clear()

        listView = findViewById(R.id.camList)
        var list = mutableListOf<Model>()
        list.clear()

        val restTask4 = RestTask4(name)
        val getResult3 = restTask4.execute().get()

        val resultSplit3 = getResult3.split(' ')
        for(i in 0 until resultSplit3.count()-1){

            var image_task: URLtoBitmapTask = URLtoBitmapTask()
            image_task = URLtoBitmapTask().apply {
                url = URL("http://${resultSplit3[i]}")
            }
            bitmap = image_task.execute().get()
            list.add(Model("No. $i", "${resultSplit3[i]}", this.bitmap))
        }

        listView.adapter = MyListAdapter(this,R.layout.row,list)
        listView.setOnItemClickListener{parent, view, position, id ->
        //누르면 반응하는 부분
            //ImageDownload().execute(resultSplit3[position])
            Log.e(tag, resultSplit3[position])
            //Toast.makeText(this@MainActivity, "저장되었습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private class ImageDownload : AsyncTask<String?, Void?, Void?>() {
        /**
         * 파일명
         */
        private var fileName: String? = null

        /**
         * 저장할 폴더
         */
        private val SAVE_FOLDER = "/save_folder"

        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)

            //저장한 이미지 열기
            val i = Intent(Intent.ACTION_VIEW)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val targetDir: String =
                Environment.getExternalStorageDirectory().toString().toString() + SAVE_FOLDER
            val file = File("$targetDir/$fileName.jpg")
            //type 지정 (이미지)
            i.setDataAndType(Uri.fromFile(file), "image/*")
            //getApplicationContext().startActivity(i)
            //이미지 스캔해서 갤러리 업데이트
            sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)))
        }

        override fun doInBackground(vararg p0: String?): Void? {

            //다운로드 경로를 지정
            val savePath: String =
                Environment.getExternalStorageDirectory().toString().toString() + SAVE_FOLDER
            val dir = File(savePath)

            //상위 디렉토리가 존재하지 않을 경우 생성
            if (!dir.exists()) {
                dir.mkdirs()
            }

            //파일 이름 :날짜_시간
            val day = Date()
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA)
            fileName = java.lang.String.valueOf(sdf.format(day))

            //웹 서버 쪽 파일이 있는 경로
            val fileUrl = p0[0]

            //다운로드 폴더에 동일한 파일명이 존재하는지 확인
            if (File("$savePath/$fileName").exists() === false) {
            } else {
            }
            val localPath = "$savePath/$fileName.jpg"
            try {
                val imgUrl = URL(fileUrl)
                //서버와 접속하는 클라이언트 객체 생성
                val conn =
                    imgUrl.openConnection() as HttpURLConnection
                val len = conn.contentLength
                val tmpByte = ByteArray(len)
                //입력 스트림을 구한다
                val `is` = conn.inputStream
                val file = File(localPath)
                //파일 저장 스트림 생성
                val fos = FileOutputStream(file)
                var read: Int
                //입력 스트림을 파일로 저장
                while (true) {
                    read = `is`.read(tmpByte)
                    if (read <= 0) {
                        break
                    }
                    fos.write(tmpByte, 0, read) //file 생성
                }
                `is`.close()
                fos.close()
                conn.disconnect()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }
    }

    class RestTask2(name: String) : AsyncTask<String, Void, String>() {
        private val name = name
        override fun doInBackground(vararg params: String?): String {
            val apiURL = "http://114.71.221.47:7579/Mobius/$name/opentime/la"
            Log.e("222222222", apiURL)

            val requestHeaders: MutableMap<String, String> = HashMap()
            requestHeaders["Accept"] = "application/json"
            requestHeaders["X-M2M-RI"] = "12345"
            requestHeaders["X-M2M-Origin"] = "SS"

            fun connect(apiUrl: String): HttpURLConnection {
                return try {
                    val url = URL(apiUrl)
                    (url.openConnection() as HttpURLConnection)
                } catch (e: MalformedURLException) {
                    throw java.lang.RuntimeException("API URL이 잘못되었습니다. : $apiUrl", e)
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("연결이 실패했습니다. : $apiUrl", e)
                }
            }

            fun readBody(body: InputStream):String {
                val streamReader = InputStreamReader(body)
                try{
                    BufferedReader(streamReader).use { lineReader ->
                        val responseBody = StringBuilder()
                        var line: String?
                        while (lineReader.readLine().also { line = it } != null) {
                            responseBody.append(line)
                        }
                        return responseBody.toString()
                    }
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("API 응답을 읽는데 실패했습니다.", e)
                }
            }

            fun get(apiUrl:String, requestHeaders: Map<String, String>):String{
                val con: HttpURLConnection = connect(apiUrl)

                try {
                    con.requestMethod = "GET"

                    for(header : Map.Entry<String, String> in requestHeaders.entries) {
                        con.setRequestProperty(header.key, header.value)
                        Log.e("111111", header.key +" _ "+ con.getRequestProperty(header.key).toString())
                    }

                    val responseCode = con.responseCode
                    Log.e("here1", responseCode.toString())
                    return if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 응답
                        readBody(con.inputStream);
                    } else {  // 에러 응답
                        readBody(con.errorStream);
                    }
                }catch (e: IOException) {
                    throw java.lang.RuntimeException("API 요청과 응답 실패", e)
                }finally {
                    con.disconnect();
                }
            }

            val responseGET: String = get(apiURL, requestHeaders)
            println(responseGET)


            var parser: JsonParser = JsonParser()
            var element: JsonElement = parser.parse(responseGET)
            var data:String=""

            if(element.asJsonObject.get("m2m:dbg") != null){
                Log.e("오류", "오류가 발생했습니다." + "[오류 코드: "+ element.asJsonObject.get("m2m:dbg").asString + "]")
                data = "A: 오류입니다."
            } else if (element.asJsonObject.get("m2m:cin") != null){
                //Log.e("here", element.asJsonObject.get("m2m:cin").asJsonObject.get("con").asString as Nothing)
                data = element.asJsonObject.get("m2m:cin").asJsonObject.get("con").asString
                Log.e("성공", "값은: $data")
            }

            return data;
        }
    }

    class RestTask3(name: String) : AsyncTask<String, Void, String>() {
        private val name = name

        override fun doInBackground(vararg params: String?): String {
            val apiURL = "http://114.71.221.47:7579/Mobius/$name/food?rcn=4"
            Log.e("222222222", apiURL)

            val requestHeaders: MutableMap<String, String> = HashMap()
            requestHeaders["Accept"] = "application/json"
            requestHeaders["X-M2M-RI"] = "12345"
            requestHeaders["X-M2M-Origin"] = "SS"

            fun connect(apiUrl: String): HttpURLConnection {
                return try {
                    val url = URL(apiUrl)
                    (url.openConnection() as HttpURLConnection)
                } catch (e: MalformedURLException) {
                    throw java.lang.RuntimeException("API URL이 잘못되었습니다. : $apiUrl", e)
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("연결이 실패했습니다. : $apiUrl", e)
                }
            }

            fun readBody(body: InputStream):String {
                val streamReader = InputStreamReader(body)
                try{
                    BufferedReader(streamReader).use { lineReader ->
                        val responseBody = StringBuilder()
                        var line: String?
                        while (lineReader.readLine().also { line = it } != null) {
                            responseBody.append(line)
                        }
                        return responseBody.toString()
                    }
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("API 응답을 읽는데 실패했습니다.", e)
                }
            }

            fun get(apiUrl:String, requestHeaders: Map<String, String>):String{
                val con: HttpURLConnection = connect(apiUrl)

                try {
                    con.requestMethod = "GET"

                    for(header : Map.Entry<String, String> in requestHeaders.entries) {
                        con.setRequestProperty(header.key, header.value)
                        Log.e("111111", header.key +" _ "+ con.getRequestProperty(header.key).toString())
                    }

                    val responseCode = con.responseCode
                    Log.e("here1", responseCode.toString())
                    return if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 응답
                        readBody(con.inputStream);
                    } else {  // 에러 응답
                        readBody(con.errorStream);
                    }
                }catch (e: IOException) {
                    throw java.lang.RuntimeException("API 요청과 응답 실패", e)
                }finally {
                    con.disconnect();
                }
            }

            val responseGET: String = get(apiURL, requestHeaders)
            println(responseGET)


            var parser: JsonParser = JsonParser()
            var element: JsonElement = parser.parse(responseGET)
            var data=""

            if(element.asJsonObject.get("m2m:dbg") != null){
                Log.e("오류", "오류가 발생했습니다." + "[오류 코드: "+ element.asJsonObject.get("m2m:dbg").asString + "]")
                data = "A: 오류입니다."
            } else if (element.asJsonObject.get("m2m:rsp") != null){
                //Log.e("here", element.asJsonObject.get("m2m:cin").asJsonObject.get("con").asString as Nothing)
                val data1 = element.asJsonObject.get("m2m:rsp").asJsonObject.get("m2m:cnt").asJsonArray
                for (i in 0 until data1.count()){
                    data += data1[i].asJsonObject.get("rn").asString
                    data += ' '
                }
                Log.e("성공", "값은: $data")
            }

            return data;
        }
    }

    class RestTask4(name: String) : AsyncTask<String, Void, String>() {
        private val name = name

        override fun doInBackground(vararg params: String?): String {
            val apiURL = "http://114.71.221.47:7579/Mobius/$name/cam?rcn=4"
            Log.e("222222222", apiURL)

            val requestHeaders: MutableMap<String, String> = HashMap()
            requestHeaders["Accept"] = "application/json"
            requestHeaders["X-M2M-RI"] = "12345"
            requestHeaders["X-M2M-Origin"] = "SS"

            fun connect(apiUrl: String): HttpURLConnection {
                return try {
                    val url = URL(apiUrl)
                    (url.openConnection() as HttpURLConnection)
                } catch (e: MalformedURLException) {
                    throw java.lang.RuntimeException("API URL이 잘못되었습니다. : $apiUrl", e)
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("연결이 실패했습니다. : $apiUrl", e)
                }
            }

            fun readBody(body: InputStream):String {
                val streamReader = InputStreamReader(body)
                try{
                    BufferedReader(streamReader).use { lineReader ->
                        val responseBody = StringBuilder()
                        var line: String?
                        while (lineReader.readLine().also { line = it } != null) {
                            responseBody.append(line)
                        }
                        return responseBody.toString()
                    }
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("API 응답을 읽는데 실패했습니다.", e)
                }
            }

            fun get(apiUrl:String, requestHeaders: Map<String, String>):String{
                val con: HttpURLConnection = connect(apiUrl)

                try {
                    con.requestMethod = "GET"

                    for(header : Map.Entry<String, String> in requestHeaders.entries) {
                        con.setRequestProperty(header.key, header.value)
                        Log.e("111111", header.key +" _ "+ con.getRequestProperty(header.key).toString())
                    }

                    val responseCode = con.responseCode
                    Log.e("here1", responseCode.toString())
                    return if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 응답
                        readBody(con.inputStream);
                    } else {  // 에러 응답
                        readBody(con.errorStream);
                    }
                }catch (e: IOException) {
                    throw java.lang.RuntimeException("API 요청과 응답 실패", e)
                }finally {
                    con.disconnect();
                }
            }

            val responseGET: String = get(apiURL, requestHeaders)
            println(responseGET)


            var parser: JsonParser = JsonParser()
            var element: JsonElement = parser.parse(responseGET)
            var data=""

            if(element.asJsonObject.get("m2m:dbg") != null){
                Log.e("오류", "오류가 발생했습니다." + "[오류 코드: "+ element.asJsonObject.get("m2m:dbg").asString + "]")
                data = "A: 오류입니다."
            } else if (element.asJsonObject.get("m2m:rsp") != null){
                //Log.e("here", element.asJsonObject.get("m2m:cin").asJsonObject.get("con").asString as Nothing)
                val data1 = element.asJsonObject.get("m2m:rsp").asJsonObject.get("m2m:cin").asJsonArray
                for (i in 0 until data1.count()){
                    data += data1[i].asJsonObject.get("con").asString
                    data += ' '
                }
                Log.e("성공", "값은: $data")
            }

            return data;
        }
    }
}

//https://recipes4dev.tistory.com/45