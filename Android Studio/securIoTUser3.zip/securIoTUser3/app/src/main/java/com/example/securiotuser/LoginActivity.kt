package com.example.securiotuser

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.android.synthetic.main.activity_login.*
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

class LoginActivity : AppCompatActivity() {
    private val tag = "LoginActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //로그인
        login_button.setOnClickListener{
            val id = idText.text.toString()
            val pw = pwText.text.toString()

            if(!id.isNullOrEmpty() && !pw.isNullOrEmpty()){
                val combine = id+'_'+pw

                val restTask = RestTask1(combine)
                val getResult = restTask.execute().get()

                if(getResult=="ok"){
                    var intent1 = Intent(this@LoginActivity, MainActivity::class.java) //코틀린에서만 쓰는 java와 호환을 위한 새로운 문법
                    intent1.putExtra("ID", id)
                    startActivity(intent1)
                }
                else{
                    Toast.makeText(this, "등록된 학번이 아니거나 비밀번호가 틀립니다.", Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this, "학번과 비밀번호를를 입력하세요.", Toast.LENGTH_SHORT).show()
            }
        }

        Log.e(tag, "onCreate")
    }

    class RestTask1(IdPw: String) : AsyncTask<String, Void, String> () {
        private val IdPw = IdPw

        override fun doInBackground(vararg params: String?): String {
            val apiURL = "http://114.71.221.47:7579/Mobius/PIN/$IdPw"
            Log.e("222222222", apiURL)

            val requestHeaders: MutableMap<String, String> = HashMap()
            requestHeaders["Accept"] = "application/json"
            requestHeaders["X-M2M-RI"] = "12345"
            requestHeaders["X-M2M-Origin"] = "SS"

            fun connect(apiUrl: String): HttpURLConnection {
                return try {
                    val url = URL(apiUrl)
                    (url.openConnection() as HttpURLConnection)
                } catch (e: MalformedURLException) {
                    throw java.lang.RuntimeException("API URL이 잘못되었습니다. : $apiUrl", e)
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("연결이 실패했습니다. : $apiUrl", e)
                }
            }

            fun readBody(body: InputStream):String {
                val streamReader = InputStreamReader(body)
                try{
                    BufferedReader(streamReader).use { lineReader ->
                        val responseBody = StringBuilder()
                        var line: String?
                        while (lineReader.readLine().also { line = it } != null) {
                            responseBody.append(line)
                        }
                        return responseBody.toString()
                    }
                } catch (e: IOException) {
                    throw java.lang.RuntimeException("API 응답을 읽는데 실패했습니다.", e)
                }
            }

            fun get(apiUrl:String, requestHeaders: Map<String, String>):String{
                val con: HttpURLConnection = connect(apiUrl)

                try {
                    con.requestMethod = "GET"

                    for(header : Map.Entry<String, String> in requestHeaders.entries) {
                        con.setRequestProperty(header.key, header.value)
                        Log.e("111111", header.key +" _ "+ con.getRequestProperty(header.key).toString())
                    }

                    val responseCode = con.responseCode
                    Log.e("here1", responseCode.toString())
                    return if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 응답
                        readBody(con.inputStream);
                    } else {  // 에러 응답
                        readBody(con.errorStream);
                    }
                }catch (e: IOException) {
                    throw java.lang.RuntimeException("API 요청과 응답 실패", e)
                }finally {
                    con.disconnect();
                }
            }

            val responseGET: String = get(apiURL, requestHeaders)
            println(responseGET)


            var parser: JsonParser = JsonParser()
            var element: JsonElement = parser.parse(responseGET)
            var data:String=""

            if(element.asJsonObject.get("m2m:dbg") != null){
                Log.e("오류", "오류가 발생했습니다." + "[오류 코드: "+ element.asJsonObject.get("m2m:dbg").asString + "]")
                data = "A: 오류입니다."
            } else if (element.asJsonObject.get("m2m:cnt") != null){
                //Log.e("here", element.asJsonObject.get("m2m:cin").asJsonObject.get("con").asString as Nothing)
                //data = element.asJsonObject.get("m2m:cnt").asJsonObject.get("con").asString
                data = "ok"
                Log.e("성공", "값은: $data")
            }

            return data;
        }
    }
}