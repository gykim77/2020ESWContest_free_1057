package com.example.securiotuser

import android.graphics.Bitmap

class Model(val title:String, val desc:String, val photo: Bitmap) {
}

//https://devofandroid.blogspot.com/2018/03/custom-listview-with-item-click.html